
import tensorflow as tf
from tf_agents.agents.dqn import dqn_agent
from tf_agents.networks import q_network
from tf_agents.utils import common

def create_dqn_agent(env, learning_rate=1e-3):
    q_net = q_network.QNetwork(
        env.observation_spec(),
        env.action_spec(),
        fc_layer_params=(128, 128))

    optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    train_step = common.create_variable('train_step')

    agent = dqn_agent.DqnAgent(
        env.time_step_spec(),
        env.action_spec(),
        q_network=q_net,
        optimizer=optimizer,
        td_errors_loss_fn=common.element_wise_squared_loss,
        train_step_counter=train_step)

    agent.initialize()
    return agent
