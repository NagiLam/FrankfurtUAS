import streamlit as st
import joblib

# Load model
model = joblib.load('models/traffic_classifier.pkl')

# Label mapping (example values - adjust based on your dataset)
label_map = {
    0: 'Unknown',
    1: 'HTTP',
    2: 'DNS',
    3: 'TCP',
    4: 'FTP',
    5: 'ICMP',
    6: 'TLS',
    7: 'QUIC',
    8: 'UDP'
}
# Invert the map for dropdown use
protocol_to_code = {v: k for k, v in label_map.items()}

# UI
st.title("SmartNetClassifier")

length = st.slider("Packet Length (bytes)", 0, 2000, 500)

protocol_name = st.selectbox("Protocol Type", list(protocol_to_code.keys()))
protocol_code = protocol_to_code[protocol_name]

if st.button("Classify"):
    result = model.predict([[length, protocol_code]])
    predicted_name = label_map.get(result[0], "Unknown")
    st.success(f"Predicted Protocol Class: {result[0]} ({predicted_name})")
