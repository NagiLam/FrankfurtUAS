#!/bin/bash

PCAP_FILE="/tmp/sample.pcap"
DEST_FILE="$(pwd)/sample.pcap"

echo "Capturing 30 seconds of traffic..."
sudo tshark -i any -a duration:30 -w "$PCAP_FILE"

# Move to project folder
sudo mv "$PCAP_FILE" "$DEST_FILE"

# Fix permissions
sudo chown $USER:$USER "$DEST_FILE"
sudo chmod 644 "$DEST_FILE"

echo "Capture complete: $DEST_FILE"
