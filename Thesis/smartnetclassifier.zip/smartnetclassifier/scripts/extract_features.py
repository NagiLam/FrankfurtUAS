import pyshark
import pandas as pd

def extract_features(pcap_file):
    cap = pyshark.FileCapture(pcap_file, keep_packets=False)
    records = []
    for packet in cap:
        try:
            proto = packet.highest_layer
            length = int(packet.length)
            src = packet.ip.src if hasattr(packet, 'ip') else 'N/A'
            dst = packet.ip.dst if hasattr(packet, 'ip') else 'N/A'
            records.append({
                'protocol': proto,
                'length': length,
                'source': src,
                'destination': dst
            })
        except Exception:
            continue
    cap.close()
    df = pd.DataFrame(records)
    df['protocol_code'] = df['protocol'].astype('category').cat.codes
    return df

if __name__ == "__main__":
    df = extract_features("sample.pcap")
    df.to_csv("traffic_features.csv", index=False)
    print(f"Extracted {len(df)} packets with {len(df.columns)} features.")
