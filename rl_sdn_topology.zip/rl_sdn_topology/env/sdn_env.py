
import numpy as np
from tf_agents.environments import py_environment
from tf_agents.specs import array_spec
from tf_agents.trajectories import time_step as ts
from sdn.odl_interface import get_link_utilization, modify_topology

class SDNEnv(py_environment.PyEnvironment):
    def __init__(self):
        self._action_spec = array_spec.BoundedArraySpec(
            shape=(), dtype=np.int32, minimum=0, maximum=4, name='action')
        self._observation_spec = array_spec.BoundedArraySpec(
            shape=(10,), dtype=np.float32, minimum=0, maximum=1, name='observation')

        self._state = np.zeros(10, dtype=np.float32)
        self._episode_ended = False

    def action_spec(self):
        return self._action_spec

    def observation_spec(self):
        return self._observation_spec

    def _reset(self):
        self._state = get_link_utilization()
        self._episode_ended = False
        return ts.restart(self._state)

    def _step(self, action):
        if self._episode_ended:
            return self.reset()

        modify_topology(action)
        self._state = get_link_utilization()

        # Simulate latency as mean utilization (less is better)
        avg_util = np.mean(self._state)
        max_util = np.max(self._state)
        reward = 1.0 - avg_util - 0.5 * max_util  # Penalize high average and spikes

        self._episode_ended = max_util > 0.95

        if self._episode_ended:
            return ts.termination(self._state, reward)
        else:
            return ts.transition(self._state, reward)
