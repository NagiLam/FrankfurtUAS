
from mininet.net import Mininet
from mininet.node import RemoteController
from mininet.link import TCLink
from mininet.topo import Topo
import subprocess
import os
import sys
from PIL import Image
import matplotlib.pyplot as plt

class EvaluationTopology(Topo):
    def build(self):
        s1 = self.addSwitch('s1')
        s2 = self.addSwitch('s2')
        s3 = self.addSwitch('s3')
        h1 = self.addHost('h1', ip='10.0.0.1')
        h2 = self.addHost('h2', ip='10.0.0.2')
        h3 = self.addHost('h3', ip='10.0.0.3')
        self.addLink(h1, s1)
        self.addLink(s1, s2)
        self.addLink(s2, h2)
        self.addLink(s2, s3)
        self.addLink(s3, h3)

def extract_avg_rtt(ping_output):
    for line in ping_output.split('\n'):
        if 'rtt min/avg/max/mdev' in line:
            parts = line.split('=')[1].strip().split(' ')[0].split('/')
            return float(parts[1])
    return None

def run_ping_test(src, dst):
    result = src.cmd(f'ping -c 5 {dst.IP()}')
    avg_rtt = extract_avg_rtt(result)
    return avg_rtt

def evaluate_latency():
    topo = EvaluationTopology()
    net = Mininet(topo=topo, controller=lambda name: RemoteController(name, ip='127.0.0.1'), link=TCLink)
    net.start()

    h1, h2, h3 = net.get('h1', 'h2', 'h3')

    print("\n--- Latency Test Before Training ---")
    before_rtts = [
        run_ping_test(h1, h2),
        run_ping_test(h2, h3),
        run_ping_test(h3, h1)
    ]
    print(f"Before Training RTTs: {before_rtts}")

    print("\n--- Apply RL Agent Policy (main.py) ---")
    subprocess.run(["/home/nagilam/tensorflow_311/bin/python", "main.py"], check=True)

    print("\n--- Latency Test After Training ---")
    after_rtts = [
        run_ping_test(h1, h2),
        run_ping_test(h2, h3),
        run_ping_test(h3, h1)
    ]
    print(f"After Training RTTs: {after_rtts}")

    # Save to result.txt
    with open("result.txt", "w") as f:
        f.write("Latency Before Training: " + str(before_rtts) + "\n")
        f.write("Latency After Training: " + str(after_rtts) + "\n")
    print("Saved latency results to result.txt")

    try:
        before_img = Image.open("topology_before_training.png")
        after_img = Image.open("topology_after_training.png")

        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        axes[0].imshow(before_img)
        axes[0].set_title("Topology Before Training")
        axes[0].axis('off')

        axes[1].imshow(after_img)
        axes[1].set_title("Topology After Training")
        axes[1].axis('off')

        plt.tight_layout()
        plt.savefig("topology_comparison.png")
        print("Saved topology_comparison.png")
    except Exception as e:
        print(f"Could not display topology images: {e}")

    input("\nMininet is still running for DLUX visualization. Press ENTER to stop...\n")
    net.stop()

if __name__ == '__main__':
    evaluate_latency()
