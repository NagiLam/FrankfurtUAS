
from rl_agent.agent import create_dqn_agent
from env.sdn_env import SDNEnv
from tf_agents.environments import tf_py_environment
from tf_agents.replay_buffers import tf_uniform_replay_buffer
from tf_agents.trajectories import trajectory
from tf_agents.utils import common
from sdn.odl_interface import visualize_topology

# Visualize initial topology
visualize_topology("before_training")

env = SDNEnv()
tf_env = tf_py_environment.TFPyEnvironment(env)
agent = create_dqn_agent(tf_env)
agent.train = common.function(agent.train)

replay_buffer = tf_uniform_replay_buffer.TFUniformReplayBuffer(
    data_spec=agent.collect_data_spec,
    batch_size=tf_env.batch_size,
    max_length=10000)

# Warm-up
time_step = tf_env.reset()
for _ in range(10):
    action_step = agent.collect_policy.action(time_step)
    next_time_step = tf_env.step(action_step.action)
    traj = trajectory.from_transition(time_step, action_step, next_time_step)
    replay_buffer.add_batch(traj)
    time_step = next_time_step

# Training
time_step = tf_env.reset()
for _ in range(100):
    action_step = agent.collect_policy.action(time_step)
    next_time_step = tf_env.step(action_step.action)
    traj = trajectory.from_transition(time_step, action_step, next_time_step)
    replay_buffer.add_batch(traj)

    experience = replay_buffer.as_dataset(sample_batch_size=1, num_steps=2).take(1)
    for exp, _ in experience:
        agent.train(exp)

    time_step = next_time_step

# Visualize final topology
visualize_topology("after_training")
