
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import RemoteController
from mininet.cli import CLI
from mininet.link import TCLink

class ExpandedSDNTopology(Topo):
    def build(self):
        s1 = self.addSwitch('s1')
        s2 = self.addSwitch('s2')
        s3 = self.addSwitch('s3')
        h1 = self.addHost('h1', ip='10.0.0.1')
        h2 = self.addHost('h2', ip='10.0.0.2')
        h3 = self.addHost('h3', ip='10.0.0.3')
        self.addLink(h1, s1)
        self.addLink(s1, s2)
        self.addLink(s2, h2)
        self.addLink(s2, s3)
        self.addLink(s3, h3)

def start_network():
    topo = ExpandedSDNTopology()
    net = Mininet(topo=topo, controller=lambda name: RemoteController(name, ip='127.0.0.1'), link=TCLink)
    net.start()
    print("Mininet network started.")

    print("\nRunning pingall to populate ARP tables and notify controller...")
    net.pingAll()

    print("Mininet is running. Leave this window open while training or evaluating.")
    input("Press Enter to stop Mininet...")
    net.stop()

if __name__ == '__main__':
    start_network()
