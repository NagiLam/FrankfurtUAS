
import requests
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

ODL_BASE = "http://localhost:8181/restconf"
AUTH = ('admin', 'admin')
HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}

def get_link_utilization():
    return np.random.rand(10).astype(np.float32)

def modify_topology(action):
    if action == 0:
        print("No topology change.")
    elif action == 1:
        print("Installing flow: route h1->h2 via s1->s3")
        install_flow("openflow:1", 1, "10.0.0.2", "output=2")
    elif action == 2:
        print("Installing flow: route h2->h3 via s2->s3")
        install_flow("openflow:2", 2, "10.0.0.3", "output=3")
    elif action == 3:
        print("Removing link (simulation): s1-s2")
    elif action == 4:
        print("Installing flow: force h3->h1 through s3->s1")
        install_flow("openflow:3", 3, "10.0.0.1", "output=1")

def install_flow(switch_id, flow_id, dst_ip, action_str):
    flow = {
        "flow": [
            {
                "id": str(flow_id),
                "match": {
                    "ipv4-destination": dst_ip + "/32",
                    "ethernet-match": {
                        "ethernet-type": {
                            "type": 2048
                        }
                    }
                },
                "instructions": {
                    "instruction": [
                        {
                            "order": 0,
                            "apply-actions": {
                                "action": [
                                    {
                                        "order": 0,
                                        "output-action": {
                                            "output-node-connector": action_str.split("=")[1]
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                },
                "priority": 100,
                "table_id": 0
            }
        ]
    }

    url = f"{ODL_BASE}/config/opendaylight-inventory:nodes/node/{switch_id}/table/0/flow/{flow_id}"
    response = requests.put(url, json=flow, auth=AUTH, headers=HEADERS)
    if response.status_code in [200, 201, 204]:
        print(f"Flow {flow_id} installed on {switch_id}.")
    else:
        print(f"Failed to install flow on {switch_id}: {response.status_code}, {response.text}")

def fetch_topology_from_odl():
    url = f"{ODL_BASE}/operational/network-topology:network-topology"
    response = requests.get(url, auth=AUTH, headers=HEADERS)
    response.raise_for_status()
    return response.json()

def visualize_topology(snapshot_name):
    topo_data = fetch_topology_from_odl()
    G = nx.Graph()

    try:
        links = topo_data["network-topology"]["topology"][0]["link"]
        for link in links:
            src = link["source"]["source-node"]
            dst = link["destination"]["dest-node"]
            G.add_edge(src, dst)
    except KeyError:
        print("No links found in topology data")

    plt.figure(figsize=(8, 6))
    nx.draw(G, with_labels=True, node_color='lightblue', edge_color='gray', node_size=1000)
    plt.title(f"Topology Snapshot: {snapshot_name}")
    plt.savefig(f"topology_{snapshot_name}.png")
    plt.close()
    print(f"Saved topology_{snapshot_name}.png")
